class UsersController < ApplicationController
	layout 'two'
  def index
  end

  def show
  end
end
