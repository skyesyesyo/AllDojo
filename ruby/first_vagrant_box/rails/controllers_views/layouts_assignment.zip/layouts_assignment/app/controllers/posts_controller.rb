class PostsController < ApplicationController
	layout 'three'
  def index
  end

  def show
  end
end
