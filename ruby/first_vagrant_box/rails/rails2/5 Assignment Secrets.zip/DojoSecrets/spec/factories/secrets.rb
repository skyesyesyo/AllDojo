FactoryGirl.define do
  factory :secret do
    content "Secret from FactoryGirl"
    user nil
  end
end
