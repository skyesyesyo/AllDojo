var math_module = require('./mathlib')();
console.log(math_module);
math_module.add(1,2);
math_module.square(2);
math_module.random(1,100);